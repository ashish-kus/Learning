subtract(X,Y):-
  S is X-Y,
  write(S).

