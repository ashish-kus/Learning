subtraction(X,Y):-
	Z is X-Y,
	write(Z).
 
sum(X,Y):-
	Z is X+Y,
	write(Z).

multiplication(X,Y):-
	Z is X*Y,
	write(Z).

divison(X,Y):-
	Z is X/Y,
	write(Z).

power(X,Y):-
	Z is X**Y,
	write(Z).

modulus(X,Y):-
	Z is X mod Y,
	write(Z).
